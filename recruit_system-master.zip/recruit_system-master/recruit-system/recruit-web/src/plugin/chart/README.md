# 插件名: antv charts demo(Charts)

插件描述, antv charts demo 用于处于xxx业务场景, 提供了xxx功能

## 舞台视口列表

### TestView

地址: `/Charts/test.vue`
显示xxx内容, 可进行xxx操作

## 自由视口列表

### Test

属性:

| Require | Name |  Type  | Default | Desc |
|:-------:|:----:|:------:|:-------:|:----:|
|  true   | name | String |   val   | 描述 |
  
事件:

| Name |   Argument   | Desc |
|:----:|:------------:|:----:|
| name | 事件参数描述 | 描述 |

方法:

| Name |   Argument   |   Result   | Desc |
|:----:|:------------:|:----------:|:----:|
| name | 方法参数描述 | 返回值描述 | 描述 |